if __name__ == "__main__":
    from src.ui.qt import main

    main()
