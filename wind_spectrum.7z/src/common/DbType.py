import enum


class DbType(enum.Enum):
    ISOLATED = 1
    INTERFERENCE = 2