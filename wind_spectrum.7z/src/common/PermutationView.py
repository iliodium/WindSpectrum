import enum


class PermutationView(enum.Enum):
    FORWARD = 1
    REVERSE = 2