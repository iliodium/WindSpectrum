import enum


class TypeOfBasement(enum.Enum):
    SQUARE = 1
    RECTANGLE = 2
