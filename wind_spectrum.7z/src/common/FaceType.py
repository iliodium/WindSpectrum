import enum


class FaceType(enum.Enum):
    ON_WIND = 1,
    RIGHT_WIND = 2,
    UNDER_WIND = 3,
    LEFT_WIND = 4
