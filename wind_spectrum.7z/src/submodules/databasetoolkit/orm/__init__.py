# ALL MODELS ARE GENERATED WITH sqlacodegen
# sqlacodegen_v2 postgresql://postgres:password@localhost:15432/postgres > models.py

__all__ = [
    "models"
]
